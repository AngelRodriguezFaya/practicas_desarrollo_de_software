//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        Notificador n1 = new NotificadorEmail(" Servidor Caido ");
        System.out.println(n1.enviarMensaje());

        Notificador n2 = new NotificadorSMS(" Servidor Caido ");
        System.out.println(n2.enviarMensaje());

        Notificador n3 = new NotificadorSlack(" Servidor Caido ");
        System.out.println(n3.enviarMensaje());
    }
}